<template>
  <div class="field">
    <diagram class="diagram"></diagram>
    <details-input-group class="details-input-group"></details-input-group>
    <entity-list class="table-list"></entity-list>
  </div>
</template>

<script>
import Diagram from '@component/design_db/diagram/Diagram.vue';
import DetailsInputGroup from '@component/design_db/details/DetailsInputGroup.vue';
import EntityList from '@component/design_db/entity_list/EntityList.vue';

export default {
  name: 'design-db',
  components: {
    Diagram,
    DetailsInputGroup,
    EntityList,
  }
}
</script>

<style scoped>
  .field {
    display: grid;
    grid-template-columns: 85% 15%;
    grid-template-rows: calc(70% + 50px) 30%;
  }
  .diagram {
    grid-column: 1;
    grid-row: 1;
  }
  .details-input-group {
    grid-column: 1;
    grid-row: 2;
  }
  .table-list {
    grid-column: 2;
    grid-row: 1/3;
  }

</style>