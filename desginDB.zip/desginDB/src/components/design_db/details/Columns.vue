<template>
  <div class="edit-form" :style="edit_form_styles">
    <div class="field-left">
      <div class="label">
        <label  class="label-table-name" for="table-name">Table Name</label>
        <input class="table-name-input" type="text" v-model="tableName">
      </div>
      <div class="field-left-bottom entity">
        <table class="entity-list">
          <thead>
            <tr>
              <th
                v-for="(header, index) in table_header"
                :key="index">
                  {{header}}
              </th>
            </tr>
          </thead>
          <draggable
            :element="'tbody'"
            :style="entity_tbody_styles"
            v-model="modifyColumn">
            <tr
            v-for="column in entity.columns"
            :key="column.id"
            >
              <td is="column-name-input"
                :table_id="entity.id"
                :column_id="column.id"
                :name="column.name"></td>
              <td is="column-type-input"
                :table_id="entity.id"
                :column_id="column.id"
                :type="column.type"></td>
              <td is="column-attribute-input"
                :table_id="entity.id"
                :column_id="column.id"
                :attribute_name="'pk'"
                :attribute="column.pk"></td>
              <td is="column-attribute-input"
                :table_id="entity.id"
                :column_id="column.id"
                :attribute_name="'nn'"
                :attribute="column.nn"></td>
              <td is="column-attribute-input"
                :table_id="entity.id"
                :column_id="column.id"
                :attribute_name="'uq'"
                :attribute="column.uq"></td>
              <td is="column-attribute-input"
                :table_id="entity.id"
                :column_id="column.id"
                :attribute_name="'ai'"
                :attribute="column.ai"></td>
              <td is="column-attribute-input"
                :table_id="entity.id"
                :column_id="column.id"
                :attribute_name="'un'"
                :attribute="column.un"></td>
              <td is="column-attribute-input"
                :table_id="entity.id"
                :column_id="column.id"
                :attribute_name="'zf'"
                :attribute="column.zf"></td>
              <td is="column-attribute-input"
                :table_id="entity.id"
                :column_id="column.id"
                :attribute_name="'bin'"
                :attribute="column.bin"></td>
              <td is="column-def-exp-input"
                :table_id="entity.id"
                :column_id="column.id"
                :def_exp="column.def_exp"
                ></td>
            </tr>
          </draggable>
        </table>
      </div>
    </div>
    <div class="field-right">
      <div class="filed-right-top">
        <div class="tool-buttons">
          <label for="tool" class="label-tool-button">Tool Buttons</label>
          <div class="button-group">
            <ul>
              <li><button @click="addColumn(entity.id)">add</button></li>
              <li><button>drop</button></li>
            </ul>
          </div>
        </div>
      </div>
      <div class=" filed-right-bottom">
        <div class="comment">
          <label for="comment" class="label-comment">Comment</label>
          <textarea class="comment-textarea"></textarea>
          <div class="counter"><span> /400</span></div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
import draggable from 'vuedraggable';

import TBColumnNameInput from '@component/design_db/details/TBColumnNameInput.vue';
import TBColumnTypeInput from '@component/design_db/details/TBColumnTypeInput.vue';
import TBColumnAttributeInput from '@component/design_db/details/TBColumnAttributeInput.vue';
import TBColumnDefExpInput from '@component/design_db/details/TBColumnDefExpInput.vue';
export default {
  name: 'columns',
  components: {
    draggable,
    'column-name-input': TBColumnNameInput,
    'column-type-input': TBColumnTypeInput,
    'column-attribute-input': TBColumnAttributeInput,
    'column-def-exp-input': TBColumnDefExpInput,
  },
  props: {
    parent_height: Number,
  },
  data() {
    return {
      edit_form_padding: [10, 10, 10, 10],
      label_height: 24,
      entity_margin: [10, 0, 0, 0],
      table_header: ['Column Name', 'Datatype', 'PK', 'NN', 'UQ', 'AI', 'UN', 'ZF', 'BIN', 'Default/Expression'],
      entity: {},
      select_column_id: null,
    }
  },
  watch: {
    getSelectNode: function(val) {
      this.entity = this.getOneTable(val)
    }
  },
  computed: {
    ...mapGetters('status', [ 'getSelectNode' ]),
    ...mapGetters('table', [ 'getOneTable' ]),
    edit_form_styles() {
      return Object.assign(
        {}, 
        this.height(this.parent_height-20),
      );
    },
    entity_tbody_styles() {
      return Object.assign({}, this.height(this.parent_height-72),
      );
    },
    height() {
      return function(height) {
        return {'height': height + 'px'};
      }
    },
    tableName: {
      get () {
        return this.entity.table_name;
      },
      set (name) {
        this.s_changeTableName({
          table_id: this.getSelectNode,
          table_name: name,
        });
      },
    },
    modifyColumn: {
      get () {
        return this.entity.columns;
      },
      set(val) {
        this.s_changeModifiedColumns({
          table_id: this.getSelectNode,
          columns: val
        });
      }
    }
  },
  methods: {
    ...mapActions('table', {
      s_addColumn: 'addColumn',
      s_changeTableName: 'changeTableName',
      s_changeModifiedColumns: 'changeModifiedColumns',
    }),
    async addColumn(node_id) {
      await this.s_addColumn({id: node_id});
    },
  }
}
</script>

<style scoped>
  .edit-form {
    display: grid;
    grid-template-columns: 750px 1fr;
    width: calc(100% - 20px);
    height: calc(100% - 50px);
    padding: 10px;
    background-color: #ffffff;
  }
  .field-left {
    grid-column: 1;
  }
  .field-right {
    display: grid;
    grid-template-rows: 80px 1fr;
    grid-column: 2;
  }
  .field-right-top {
    grid-row: 1;
    width: 100%;
    height: 100%;
  }
  .field-right-bottom {
    grid-row: 2;
    width: 100%;
    height: 100%;
  }
  .label {
    height: 20px;
  }
  .label-table-name,
  .label-comment {
    font-family: sans-serif;
    box-sizing: border-box;
    color: rgba(0, 0, 0, 0.54);
  }
  .label-tool-button {
    display: block;
    font-family: sans-serif;
    box-sizing: border-box;
    color: rgba(0, 0, 0, 0.54);
  }
  .button-group {
    margin-top: 5px;
    box-sizing: border-box;
  }
  .button-group ul {
    display: flex;
    -ms-flex-wrap: wrap;
    flex-wrap: wrap;
    padding-left: 0;
    margin-bottom: 0;
    list-style: none;
  }
  .button-group ul li  {
    margin: 0px 5px;
  }
  .button-group button {
    width: 55px;
    border: solid 2px rgba(0,0,0,.12);
    background-color: #ffffff;
    box-shadow: 1px 1px #bbb;
    font-family: sans-serif;
    font-size: 16px;
    font-weight: 100;
    color: rgba(0, 0, 0, 0.54);
  }
  .table-name-input {
    margin-left: 10px;
    border: 0;
    border-bottom: 1px solid rgba(0,0,0,.12);
    padding-left: 5px;
    font-family: sans-serif;
    font-size: 14px;
    font-weight: 100;
    color: rgba(0,0,0,.75);
  }
  .tool-buttons {
    margin-top: 20px;
  }
  .comment-textarea {
    width: 100%;
    height: calc(100% - 75px);
    padding: 0;
    box-sizing: border-box;
    resize: none;
  }
  .comment {
    height: 100%;
  }
  .comment .counter {
    padding-right: 10px;
    text-align: right;
    color: rgba(0, 0, 0, 0.54);
  }
  .entity-list {
    width: 100%;
    border-radius: 2px;
    border-collapse: collapse;
    border-spacing: 0;
    background-color: #fff;
    color: rgba(0,0,0,.87);
  }
  .entity-list tr:nth-child(2n + 1) {
    background-color: #fff;
  }
  .entity-list tr:nth-child(2n) {
    background-color: #f9f9f9;
  }
  .entity-list thead {
    display: block;
    position: sticky;
    height: 32px;
    color: rgba(0, 0, 0, 0.54);
  }
  .entity-list thead tr {
    height: 32px;
  }
  .entity-list tbody {
    display: block;
    overflow-y: scroll;
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
  .entity-list tbody::-webkit-scrollbar {
    display:none;
  }
  .entity-list tbody tr:not(:last-child) {
    border-bottom: 1px solid rgba(0,0,0,.12);
  }
  .entity-list th  {
    display: table-cell;
    height: 32px;
    border-right:  1px solid rgba(0,0,0,.12);
    padding: 0 5px;
    font-size: 16px;
    font-weight: 100;
    text-align: left;
    font-family: sans-serif;
    vertical-align: middle;
  }
  .entity-list th:nth-child(1),
  .entity-list td:nth-child(1) {
    width: 110px;
  }
  .entity-list th:nth-child(2),
  .entity-list td:nth-child(2) {
    width: 80px;
  }
  .entity-list th:nth-child(n + 3):nth-child(-n + 9),
  .entity-list td:nth-child(n + 3):nth-child(-n + 9) {
    width: 30px;
  }
  .entity-list th:nth-child(10),
  .entity-list td:nth-child(10) {
    width: 200px;
  }
  /deep/ .entity-column-input {
    display: block;
    width: 100%;
    margin: 0;
    border: 0;
    border-bottom: 1px solid rgba(0,0,0,.12);
    padding: 0;
    padding-left: 5px;
    font-family: sans-serif;
    font-size: 14px;
    font-weight: 100;
    color: rgba(0,0,0,.75);
    background-color: rgba(0, 0, 0, 0);
  }
  /deep/ .entity-column-input::placeholder {
    color: rgba(255, 0, 0, .60);
  }
  /deep/ .entity-list td {
    display: table-cell;
    height: 28px;
    padding: 0 5px;
    font-size: 16px;
    font-weight: 100;
    font-family: sans-serif;
    vertical-align: middle;
  }


</style>