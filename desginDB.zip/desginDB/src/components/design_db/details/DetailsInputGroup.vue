<template>
    <div class="details-input-group-box">
      <div class="details-input-group-content">
        <tabs :parent_height="height"></tabs>
      </div>  
    </div>
</template>

<script>
import Tabs from '@component/design_db/details/Tabs.vue';

export default {
  name: 'details-input-group',
  components: {
    Tabs,
  },
  data() {
    return {
      height: 0,
    }
  },
  created: function() {
    addEventListener('resize', this.handleResize);
  },
  beforeDestroyed: function() {
    removeEventListener('resize', this.handleResize)
  },
  mounted() {
      this.handleResize();
  },
  methods: {
    handleResize() {
      this.height = this.$el.clientHeight - 20;
    },
  }
}
</script>

<style scoped>
  .details-input-group-box {
    background-color: #e2e2e2;
  }
  .details-input-group-content {
    width: calc(100% - 10px);
    height: calc(100% - 20px);
    margin: 10px 0px 10px 10px;
    overflow: hidden;
    box-sizing: border-box;
    position: relative;
  }
</style>