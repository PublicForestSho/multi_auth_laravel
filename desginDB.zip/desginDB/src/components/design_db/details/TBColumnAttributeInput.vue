<template>
    <td><input class="entity-column-checkbox" type="checkbox" v-model="columnAttribute"></td>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
	props: {
			table_id: Number,
      column_id: Number,
      attribute_name: String,
			attribute: Boolean,
	},
	computed: {
		...mapGetters('table', ['getColumnParameter']),
		columnAttribute: {
			get() {
				return this.getColumnParameter(this.table_id, this.column_id, this.attribute_name);
			},
			set (value) {
				this.s_changeColumnParameter({
					table_id: this.table_id,
					column_id: this.column_id,
					key: this.attribute_name,
					parameter: value
				});
			}
		}
	},
	methods: {
		...mapActions('table', {
			s_changeColumnParameter: 'changeColumnParameter',
		}),
	}
}
</script>