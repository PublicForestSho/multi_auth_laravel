<template>
  <td><input class="entity-column-input" type="text" v-model="columnDefExp"></td>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
	props: {
			table_id: Number,
			column_id: Number,
			def_exp: String,
	},
	computed: {
		...mapGetters('table', ['getColumnParameter']),
		columnDefExp: {
			get() {
				return this.getColumnParameter(this.table_id, this.column_id, 'def_exp');
			},
			set (value) {
				this.s_changeColumnParameter({
					table_id: this.table_id,
					column_id: this.column_id,
					key: 'def_exp',
					parameter: value
				});
			}
		}
	},
	methods: {
		...mapActions('table', {
			s_changeColumnParameter: 'changeColumnParameter',
		}),
	}
}
</script>