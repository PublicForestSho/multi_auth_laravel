<template>
    <td>
      <input class="entity-column-input" type="text" v-model="columnName" placeholder="none">
    </td>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
  name: 'table-body',
  props: {
    table_id: Number,
    column_id: Number,
    name: String,
  },
  computed: {
    ...mapGetters('table', ['getColumnParameter']),

    columnName: {
      get () {
        return this.getColumnParameter(this.table_id, this.column_id, 'name');
      },
      set (name) {
        this.s_changeColumnParameter({
          table_id: this.table_id, 
          column_id: this.column_id,
          key: 'name',
          parameter: name});
      },
     },
  },
  methods: {
    ...mapActions('table', {
      s_changeColumnParameter: 'changeColumnParameter',
    }),
  }
}
</script>

<style scoped>
</style>