<template>
    <td><input class="entity-column-input" type="text" v-model="columnType" placeholder="none"></td>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
  name: 'table-body',
  props: {
    table_id: Number,
    column_id: Number,
    type: String,
  },
  computed: {
    ...mapGetters('table', ['getColumnParameter']),
    columnType: {
      get () {
        return this.getColumnParameter(this.table_id, this.column_id, 'type');
      },
      set (type) {
        this.s_changeColumnParameter({
          table_id: this.table_id, 
          column_id: this.column_id,
          key: 'type',
          parameter: type});
      },
    }
  },
  methods: {
    ...mapActions('table', {
      s_changeColumnParameter: 'changeColumnParameter',
    }),
  }
}
</script>

<style scoped>
</style>