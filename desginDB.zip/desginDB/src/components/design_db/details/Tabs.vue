<template>
  <div class="tabs" :style="tabs_styles">
    <ul class="nav nav-tabs">
      <li 
        class="nav-item"
        v-for="(nav_item, index) in nav_lists"
        :key="index">
        <span 
          class="nav-link"
          :class="{'active': is_active === nav_item.id}"
          @click="handleClick(nav_item.id, nav_item.href)">
            {{nav_item.name}}
        </span>
      </li>
    </ul>
    <router-view
      :parent_height="parent_height - 30"
    />
  </div>
</template>

<script>
export default {
  name: 'tabs',
  props: {
    parent_height: Number,
  },
  data() {
    return {
      is_active: 1,
      nav_lists: [
        { id: 1,  name: 'columns', href: "/details/columns" },
        { id: 2,  name: 'indexs', href: "/details/indexs" },
        { id: 3,  name: 'foreign key', href: "/details/foreign" },
        { id: 4,  name: 'export', href: "/details/export" },
      ]
    }
  },
  computed: {
    tabs_styles() {
      return Object.assign(
        {}, 
        this.height(this.parent_height),
      );
    },
    height() {
      return function(height) {
        return {'height': height + 'px'};
      }
    },
  },
  methods: {
    handleClick(id, href) {
      this.changeTabActiveTarget(id);
      this.toRedirect(href);
    },
    changeTabActiveTarget(id) {
      this.is_active = id;
    },
    toRedirect(href) {
      this.$router.push({path: href});
    }
  }
}

</script>

<style scoped>
.nav {
  display: flex;
  -ms-flex-wrap: wrap;
  flex-wrap: wrap;
  padding-left: 0;
  margin-bottom: 0;
  list-style: none;
}
.nav-tabs {
  height: 30px;
  border-bottom:none;
}
.nav-tabs .nav-item {
  background-color: #e2e2e2;
}
.nav-tabs .nav-link {
  display: block;
  height: 100%;
  padding: 6px 16px;
  box-sizing: border-box;
  text-align: center;
  font-family: sans-serif;
  color: rgba(0,0,0,.70);
}
.active {
  background: #ffffff;
  color: #2926eeb0 !important;
}
</style>