<template>
  <div
    class="diagram"
    @mousemove="handleMousemove($event)"
  >
    <svg 
      class="line-field"
      @click.right.prevent.self="showContentMenu"
    >
      <link-line
        v-for="line in lines"
        v-bind:key="line.id"
        :id="line.id"
        :mouse="checkMouse(line.sockets[1].node_id)"
        :x1="line.sockets[0].position.x"
        :y1="line.sockets[0].position.y"
        :x2="line.sockets[1].position.x"
        :y2="line.sockets[1].position.y"
        :direction1="line.sockets[0].direction"
        :direction2="line.sockets[1].direction"
      ></link-line>
    </svg>
    <node-table
      v-for="table in tables"
      :key="table.id"
      :node_id="table.id"
      ref="node"
      @sendToParentOrderChangeSocketDirection="broadcastNode"
    />
    <transition >
      <menu-list
        class="menu"
        v-show="getShowMenu"
        :position="menu_position"
        @p_addTable="addTable"
        @changeShowMenu="changeShowMenu"
      />  
    </transition>
  </div>
</template>

<script>
  import { mapGetters, mapActions } from 'vuex';
  import Menu from '@component/design_db/diagram/Menu.vue';
  import Table from '@component/design_db/diagram/node/Table.vue';
  import Line from '@component/design_db/diagram/Line.vue';

  export default {
    name: 'diagram',
    components: {
      'menu-list': Menu,
      'node-table': Table,
      'link-line': Line,
    },
    data() {
      return {
        tables: [],
        lines: [],
        menu_position: { x: 0, y: 0},
      }
    },
    watch: {
      getAllLines: function() {
        this.lines = this.getAllLines;
      },
      getAllTables: function() {
        this.tables = this.getAllTables;
      }
    },
    created() {
      this.tables = this.getAllTables;
    },
    computed: {
      ...mapGetters('status', ['getMousePosition', 'getDrawTrigger', 'getShowMenu']),
      ...mapGetters('table', ['getAllTables']),
      ...mapGetters('line', ['getAllLines', 'getLineId']),
      checkMouse() {
        return function(node_id) {
          return node_id === 'mouse' ? true : false;
        }
      }
    },
    methods: {
      ...mapActions('status', {
        s_chgMousePos: 'changeMousePosition',
        s_chgSelectNode: 'changeSelectNode',
        s_chgShowMenu: 'changeShowMenu',
      }),
      ...mapActions('line', {
        s_chgSocketPos: 'changeSocketPosition',
      }),
      handleMousemove(event) {
        this.getDrawTrigger ? this.drawLine(event.pageX, event.pageY) : null;
        this.setMousePosition(event.pageX, event.pageY);
      },
      showContentMenu(event) {
        if (!this.getShowMenu) {
          this.s_chgShowMenu(true);
          this.menu_position = { x: event.pageX-20, y: event.pageY-20};
        }
      },
      changeShowMenu(flug) {
      this.is_show_menu = flug;
      },
      addTable() {
        this.tables = this.getAllTables;
      },
      async setMousePosition(x, y) {
        await this.s_chgMousePos({x: x, y: y});
      },
      async drawLine(x , y) {
        await this.s_chgSocketPos({
           line_id: this.getLineId,
           node_id: 'mouse',
           socket_id: 'mouse',
           position: {x: x, y: y}
        });
        this.$refs.node.forEach(el => {
          el.setSocketDirectionDrawing();
        });
      },
      broadcastNode() {
        this.$refs.node.forEach(el => {
          el.setSocketDirection();
        })
      },
    }
  }
</script>
<style>
.moveable-line {
  background: rgba(0, 0, 0, 0) !important;
}
</style>

<style scoped>
  .diagram {
    position: relative;
    width: 100%;
    height: 100%;
    overflow: hidden;
    resize: none;
  }
  .line-field {
    position: absolute;
  }
  .v-enter-active,
  .v-leave-active {
    transition: opacity 0.3s;
  }
  .v-enter,
  .v-leave-to {
    opacity: 0;
  }
  .line-field {
    width: 100%;
    height: 100%;
  }
  .menu {
    position: absolute;
  }
</style>