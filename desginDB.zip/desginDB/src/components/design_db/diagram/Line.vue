<template>
  <g>
    <line 
      v-if="mode=='straight'"
      :x1="x1" :y1="y1" :x2="x2" :y2="y2"
      :stroke=color
      stroke-width="4px">
    </line>
    <polyline
      v-if="mode=='uncinata'"
      fill="none"
      :points=uncinata_points
      :stroke=color
      stroke-width="4px">
    </polyline>
    <polyline
      v-if="mode=='sharped'"
      fill="none"
      :points=sharped_points
      :stroke=color
      stroke-width="4px">
    </polyline>
  </g>
</template>

<script>
export default {
  name: 'link-line',
  props: [ 'id', 'mouse', 'x1', 'y1', 'x2', 'y2', 'direction1', 'direction2' ],
  data() {
    return {
      mode: 'straight',
      sharped_pattern: '',
      corner_x1: 0,
      corner_y1: 0,
      corner_x2: 0,
      corner_y2: 0,
    }
  },
  watch: {
    _position: { 
      handler() {
        if (!this.mouse) {
          if 
          ((this.direction1==='top'||this.direction1==='bottom')
          &&(this.direction2==='top'||this.direction2==='bottom')) {
            this.corner_x1 = this.x1;
            this.corner_x2 = this.x2;
            if (this.y1 > this.y2) {
              this.mode = 'uncinata'
              this.corner_y1 = this.y1 - (this.y1-this.y2)/2;
              this.corner_y2 = this.y1 - (this.y1-this.y2)/2;
            } else if (this.y1 < this.y2) {
              this.mode = 'uncinata'
              this.corner_y1 = this.y2 - (this.y2-this.y1)/2;
              this.corner_y2 = this.y2 - (this.y2-this.y1)/2;
            }
          } else if 
          ((this.direction1==='right'||this.direction1==='left')
          &&(this.direction2==='right'||this.direction2==='left')) {
            this.corner_y1 = this.y1;
            this.corner_y2 = this.y2;
            if (this.x1 > this.x2) {
              this.mode = 'uncinata';
              this.corner_x1 = this.x1 - (this.x1-this.x2)/2;
              this.corner_x2 = this.x1 - (this.x1-this.x2)/2;
            } else if (this.x1 < this.x2) {
              this.mode = 'uncinata';
              this.corner_x1 = this.x2 - (this.x2-this.x1)/2;
              this.corner_x2 = this.x2 - (this.x2-this.x1)/2;
            }
          } else if 
          ((this.direction1==='top'||this.direction1==='bottom')
          &&(this.direction2==='right'||this.direction2==='left')) {
            this.mode = 'sharped';
            this.sharped_pattern = 'vertical';
          } else if
            ((this.direction1==='right'||this.direction1==='left')
          &&(this.direction2==='top'||this.direction2==='bottom')) {
            this.mode = 'sharped';
            this.sharped_pattern = 'horizontal';
          }
        }
      }
    }
  },
  computed: {
    _position() {
      return [this.x1, this.y1, this.x2, this.y2];
    },
    color() {
      return "rgba(81, 90, 110, 0.3)";
    },
    uncinata_points() {
      return this.x1+","+this.y1+" "+this.corner_x1+","+this.corner_y1+" "+this.corner_x2+","+this.corner_y2+" "+this.x2+","+this.y2;
    },
    sharped_points() {
      return this.sharped_pattern === 'vertical'
        ? this.x1+","+this.y1+" "+this.x1+","+this.y2+" "+this.x2+","+this.y2
        : this.x1+","+this.y1+" "+this.x2+","+this.y1+" "+this.x2+","+this.y2;
    }
  }
}
</script>