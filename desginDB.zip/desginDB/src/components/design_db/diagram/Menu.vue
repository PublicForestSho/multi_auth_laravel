<template>
  <div
    class="menu"
    :style="styles"
    @mouseover="onMouseEnter"
    @mouseleave="onMouseLeave">
    <ul>
      <li
        v-for="(action) in actions" 
        v-bind:key="action.id"
        @click="action.method()"
        >{{action.name}}</li>
    </ul>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
  name: 'menuList',

  data: function() {
    return {
      actions: [
        { id: 1, name: 'add', method: () => {this.addTable()} },
        { id: 2, name: 'test1' },
        { id: 3, name: 'test2' },
      ]
    }
  },
  props: ['position'],
  computed: {
    ...mapGetters('status', ['getMousePosition', 'getShowMenu']),
    styles() {
      return Object.assign({}, this.translate)
    },
    translate() {
      return { 'transform': 'translate('+this.position.x+'px,'+this.position.y+'px)' };
    },
  },

  methods: {
    ...mapActions('status', {
      s_chgShowMenu: 'changeShowMenu',
    }),
    ...mapActions('table', {
      s_createTable: 'createTable',
    }),
    onMouseEnter: function() {
      this.$emit('changeShowMenu', true);
    },
    onMouseLeave: function() {
      this.s_chgShowMenu(false);
    },
    addTable: function() {
      this.s_createTable({name: 'table', position: {x: this.positionx, y: this.position.y}});
      this.s_chgShowMenu(false);
    },
  }
}
</script>

<style scoped>
  .menu {
    position: absolute;
    border: 2px solid #606060;
    border-radius: 10px;
    background: rgba(245, 245, 245, 0.8);
    box-sizing: content-box;
    font-family: sans-serif;
  }

  ul {
    position: relative;
    min-width: 100px;
    padding: 0px;
    list-style: none;
    overflow: hidden;
  }

  li {
    position: relative;
    min-width: 140px;
    display: block;
    padding-left: 20px;
    height: 40px;
    line-height: 40px;
    overflow: hidden;
    box-sizing: content-box;
    user-select: none;
    text-decoration: none;
    font-size: 16px;
  }

  li:hover {
    background: rgba(200, 200, 200, 0.8);
  }
</style>