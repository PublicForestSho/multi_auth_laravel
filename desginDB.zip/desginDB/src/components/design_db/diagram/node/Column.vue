<template>
  <div class="field">
    <span class="column">
      <input
        class="input-column input-column-name"
        type="text"
        v-model="columnName"
        ref="nameInput"
        @click="focusNameInput"
        placeholder="none"/>
    </span>
    <span class="column">
      <input
        class="input-column input-column-type"
        type="text"
        v-model="columnType"
        ref="typeInput"
        @click="focusTypeInput"
        placeholder="none"/>
    </span>
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';

export default {
    name: 'column',
    props: ['table_id', 'column_id'],

    computed: {
      ...mapGetters('table', ['getColumnParameter']),
      columnName: {
        get () {
          return this.getColumnParameter(this.table_id, this.column_id, 'name');
        },
        set (name) {
          this.s_changeColumnParameter({
            table_id: this.table_id, 
            column_id: this.column_id,
            key: 'name',
            parameter: name});
        },
      },
      columnType: {
        get () {
          return this.getColumnParameter(this.table_id, this.column_id, 'type');
        },
        set (type) {
          this.s_changeColumnParameter({
            table_id: this.table_id, 
            column_id: this.column_id,
            key: 'type',
            parameter: type});
        },
      }
    },

  methods: {
    ...mapActions('table', {
      s_changeColumnParameter: 'changeColumnParameter',
    }),
    focusNameInput() {
      this.$refs.nameInput.focus();
    },
    focusTypeInput() {
      this.$refs.typeInput.focus();
    },
  }
}
</script>

<style scoped>
  .field {
    margin: 0 20px 10px 10px;
  }
  .column {
    color: white;
    font-family: sans-serif;
    font-size: 16px;
  }
  .input-column {
    background: none;
    border: none;
    color: white;
    font-family: sans-serif;
    font-size: 100%;
    overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
  }
  .input-column-name {
    margin-left: 10px;
    width: 120px;
    box-sizing: border-box;
  }
  .input-column:focus {
    border-radius: 30px;
    background-color: #fff;
    border: 1px solid #999;
    outline: 0;
    color: black;
    box-sizing: border-box
  }
  .input-column-type {
    margin-left: 10px;
    width: 100px;
    box-sizing: border-box;
  }
</style>