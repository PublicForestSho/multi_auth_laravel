<template>
  <div class="table-menu">
    <ul class="table-menu-button-list">
      <li v-for="action in actions"
      :key="action.id">
        <v-icon
          class="table-menu-button"
          @click="action.method(true)"
          :name="action.icon"
        />
      </li>
    </ul>
  </div>
</template>

<script>
import { mapActions } from 'vuex';
export default {
  name: 'table-menu',
  props: ['node_id'],
  data() {
    return {
      actions: [
        {
          id: 1,
          icon: 'project-diagram',
          method: (trigger) => { this.drawLine(trigger) }
        }
      ]
    }
  },
  methods: {
    ...mapActions('status', {
      s_switchDrawTrigger: 'switchDrawTrigger',
    }),
    drawLine(trigger) {
      this.s_switchDrawTrigger(trigger);
      this.$emit('createSocket');
    }
  }
}
</script>

<style scoped>
  li {
    display: block;

    overflow: hidden;
    box-sizing: content-box;
    user-select: none;
    text-decoration: none;
    font-size: 16px;
  }
  .table-menu {
    position: relative;
    list-style: none;
    padding: 5px;
  }
  .table-menu-button-list {
    position: absolute;
    right: -30px;
    background-color: #cccccc;
  }
  .table-menu-button {
    width: 24px;
    height: 24px;

  }
</style>