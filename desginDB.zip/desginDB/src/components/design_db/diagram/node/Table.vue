<template>
  <moveable
    class="node moveable"
    :style="styles"
    v-bind="moveable"
    @drag="handleDrag"
  >
    <div class="table"
      @click="handleClick"
    >
      <div class="table-name">{{ entity.table_name }}</div>
      <div class="table-header">
        <span class="table-column-header table-column-name">name</span>
        <span class="table-column-header table-column-type">type</span>
      </div>
      <column 
        v-for="(column) in entity.columns" 
        v-bind:key="column.id"
        :table_id="node_id"
        :column_id="column.id"/>
      <div class="button-area">
        <div class="add-botton">
          <v-icon name="plus" inverse scale="1.2"  @click="addColumn"/>
        </div>
      </div>
    </div>
    <table-menu
      :id="node_id"
      @createSocket="createSocket"
    />
  </moveable>
</template>

<script>
import { mapGetters, mapActions } from 'vuex';
import Moveable from 'vue-moveable';
import Menu from '@component/design_db/diagram/node/Menu.vue';
import Column from '@component/design_db/diagram/node/Column.vue'

export default {
  name: 'node-table',
  components: {
    'table-menu': Menu,
    'moveable': Moveable,
    'column': Column,
  },
  props: {node_id: Number,},
  data() {
    return {
      width: 280,
      height: 100,
      moveable: {
        draggable: true,
        throttleDrag: 10,
        snapCenter: true,
      },
      position: { x: 100, y: 100 },
      line_id_list: [],
      socket: { top: [], right: [], bottom: [], left: [] },
      socket_id: 0,
      entity: {},
    }
  },
  created() {
    let position = this.getMousePosition;
    this.entity = this.getOneTable(this.node_id);
    this.position.x = (position.x - position.x%10) - 40;
    this.position.y = (position.y - position.y%10) - 50;
    this.s_changeTablePosition({id: this.node_id, position: this.centerPosition});
  },
  watch: {
    socket: { handler() { this.moveSocket(); },
      deep: true,
    },
    position: { handler() { this.moveSocket(); },
      deep: true,
    },
    columnQuantity: {
      handler() {
        this.$nextTick( async function() {
          this.height = await this.$el.firstElementChild.clientHeight;
          await this.s_changeTablePosition({id: this.node_id, position: this.centerPosition})
          await this.moveSocket();
        });
      },
    }
  },
  computed: {
    ...mapGetters('status', ['getMousePosition', 'getDrawTrigger']),
    ...mapGetters('table', [ 'getOneTable' ]),
    ...mapGetters('line', ['getLineId', 'getTarget', 'getLinePosition', 'getLinePartnerPosition']),
    styles() {
      return Object.assign({}, this.sizeStyle, this.translate)
    },
    sizeStyle() {
      return { '--x': this.width + 'px', '--y': this.height + 'px' };
    },
    translate() {
      return { 'transform': 'translate('+this.position.x+'px,'+this.position.y+'px)' };
    },
    centerPosition() {
      return { x: this.position.x+(this.width/2), y: this.position.y+(this.height/2) };
    },
    lineSplit() {
      return function(start, length, index, division_num) {
        return Math.round(start + (length / division_num * (index + 1)));
      }
    },
    columnQuantity() {
      if (Object.keys(this.entity).length !== 0) {
        return this.entity.columns.length;
      } else {
        return '';
      }
    }
  },
  methods: {
    ...mapActions('status', {
      s_switchDrawTrigger: 'switchDrawTrigger',
      s_changeSelectNode: 'changeSelectNode',
    }),
    ...mapActions('table', {
      s_addColumn: 'addColumn',
      s_changeTablePosition: 'changeTablePosition',
    }),
    ...mapActions('line', {
      s_drawLine: 'drawLine',
      s_changeDrawingTarget: 'changeTarget',
      s_changeSocketPosition: 'changeSocketPosition',
      s_changeSocketId: 'changeSocketId',
    }),

    handleDrag({ target, transform }) {
      target.style.transform = transform;
      this.position.x = target.getBoundingClientRect().x;
      this.position.y = target.getBoundingClientRect().y;
      this.s_changeTablePosition({id: this.node_id, position: this.centerPosition})
      this.$emit('sendToParentOrderChangeSocketDirection');
    },
    handleClick() {
      this.s_changeSelectNode(this.node_id);
      this.getDrawTrigger ? this.conectSocket() : null;
    },
    addColumn() {
      this.s_addColumn({id: this.node_id});
    },
    async createSocket() {
      this.socket_id++;
      await this.s_drawLine({
        node_id: this.node_id,
        socket_id: this.socket_id,
        position: this.position,
      });
      this.line_id_list.push(this.getLineId);
      this.socket.right.push({line_id: this.getLineId, socket_id: this.socket_id});
    },
    conectSocket() {
      this.socket_id++;
      this.line_id_list.push(this.getLineId);
      this.socket.right.push({line_id: this.getLineId, socket_id: this.socket_id});
      this.s_changeSocketId({
        line_id: this.getLineId,
        before_node_id: 'mouse',
        after_node_id: this.node_id,
        before_socket_id: 'mouse',
        after_socket_id: this.socket_id
      });
      this.s_changeDrawingTarget(null);
      this.s_switchDrawTrigger(false);
      this.setSocketDirection();
    },
    setSocketPosition(line_id, node_id, socket_id, position, direction) {
      this.s_changeSocketPosition({
        line_id: line_id,
        node_id: node_id,
        socket_id: socket_id,
        position: position,
        direction: direction,
      });
    },
    moveSocket() {
      Object.keys(this.socket).forEach(key => {
        if (key == 'top') {
          this.socket[key].forEach( async (el, index, array) => {
            await this.setSocketPosition( el.line_id, this.node_id, el.socket_id,  { x:this.lineSplit(this.position.x, this.width, index, array.length+1), y: this.position.y }, 'top' );
          });
        } else if (key == 'right') {
          this.socket[key].forEach( async (el, index, array) => {
            await this.setSocketPosition( el.line_id, this.node_id, el.socket_id, { x: this.position.x+this.width, y: this.lineSplit(this.position.y, this.height, index, array.length+1) }, 'right' );
          });
        } else if (key == 'bottom') {
          this.socket[key].forEach( async (el, index, array) => {
            await this.setSocketPosition( el.line_id, this.node_id, el.socket_id, { x: this.lineSplit(this.position.x, this.width, index, array.length+1), y: this.position.y+this.height }, 'bottom' );
          });
        } else if (key == 'left') {
          this.socket[key].forEach( async (el, index, array) => {
            await this.setSocketPosition( el.line_id, this.node_id, el.socket_id, { x: this.position.x, y: this.lineSplit(this.position.y, this.height, index, array.length+1) }, 'left' );
          });
        }
      });
    },
    changeSocketDirection(target, exclude_array, line_id) {
      let i = this.socket[target].findIndex( obj =>obj.line_id === line_id);
      if (i === -1) {
        exclude_array.forEach(el => {
          let j = this.socket[el].findIndex( obj => obj.line_id === line_id)
          if (j !== -1) {
            let temp = this.socket[el][j];
            this.socket[el].splice(j, 1);
            this.socket[target].push(temp);
            return;
          }
        });
      }
    },
    setSocketDirection() {
      Object.keys(this.socket).forEach(key => {
        this.socket[key].forEach( el => {
          let tip_position = this.getLinePartnerPosition(el.line_id, this.node_id, el.socket_id);
          let falling_l_straight_line = (this.position.x-(this.position.x+this.width))*(tip_position.y-this.position.y)+(this.position.y-(this.position.y+this.height))*(this.position.x-tip_position.x);
          let rising_r_straight_line = (this.position.x-(this.position.x+this.width))*(tip_position.y-(this.position.y+this.height))+((this.position.y+this.height)-this.position.y)*(this.position.x-tip_position.x);
          if (falling_l_straight_line < 0) {
          if (rising_r_straight_line < 0) {
            //console.log('bottom');
            this.changeSocketDirection('bottom', ['top', 'right', 'left'], el.line_id);
            return;
          } else if (rising_r_straight_line > 0) {
            //console.log('left');
            this.changeSocketDirection('left', ['top', 'right', 'bottom'], el.line_id);
            return;
          }
        } else if ( falling_l_straight_line > 0) {
          if (rising_r_straight_line < 0) {
            //console.log('right');
            this.changeSocketDirection('right', ['top', 'bottom', 'left'], el.line_id);
            return;
          } else if (rising_r_straight_line > 0) {
            //console.log('top');
            this.changeSocketDirection('top', ['right', 'bottom', 'left'], el.line_id);
            return;
          }
        }
        });
      });
    },
    async setSocketDirectionDrawing() {
      if (this.getTarget === this.node_id) {
        let tip_position = this.getLinePosition(this.getLineId, 'mouse', 'mouse');
        let falling_l_straight_line = (this.position.x-(this.position.x+this.width))*(tip_position.y-this.position.y)+(this.position.y-(this.position.y+this.height))*(this.position.x-tip_position.x);
        let rising_r_straight_line = (this.position.x-(this.position.x+this.width))*(tip_position.y-(this.position.y+this.height))+((this.position.y+this.height)-this.position.y)*(this.position.x-tip_position.x);
        if (falling_l_straight_line < 0) {
          if (rising_r_straight_line < 0) {
            //console.log('bottom');
            this.changeSocketDirection('bottom', ['top', 'right', 'left'], this.getLineId);
          } else if (rising_r_straight_line > 0) {
            //console.log('left');
            this.changeSocketDirection('left', ['top', 'right', 'bottom'], this.getLineId);
          }
        } else if ( falling_l_straight_line > 0) {
          if (rising_r_straight_line < 0) {
            //console.log('right');
            this.changeSocketDirection('right', ['top', 'bottom', 'left'], this.getLineId);
          } else if (rising_r_straight_line > 0) {
            //console.log('top');
            this.changeSocketDirection('top', ['right', 'bottom', 'left'], this.getLineId);
          }
        }
      }
    }
  }
}
</script>

<style scoped>
  .node {
    --x: 0px;
    --y: 0px;
    position: absolute;
    width: var(--x);
    height: var(--y);
  }
  .table {
    background: rgba(110, 136, 255, 0.8);
    border: 2px solid #4e58bf;
    border-radius: 10px;
    cursor: pointer;
    /*min-width: 180px;*/
    padding-bottom: 6px;
    box-sizing: content-box;
    position: relative;
    user-select: none;
  }
  .table-name {
    color: white;
    font-family: sans-serif;
    font-size: 20px;
    margin-bottom: 5px;
    padding: 10px 10px 0px 20px;
  }

  .table-header {
    margin: 0 10px 10px;
    border-bottom: solid 2px white;
  }

  .table-column-header {
    display: inline-block;
    margin-left: 10px;
    margin-bottom: 5px;
    color: white;
    font-family: sans-serif;
    font-size: 16px;
  }

  .table-column-name {
    width: 120px;
  }

  .table-column-type {
    width: 100px;
  }

  .button-area {
    width: 100%;
  }

  .add-botton {
    margin-right: 20px;
    text-align: right;
  }
</style>