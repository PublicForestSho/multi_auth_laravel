<template>
  <div class="lists">
    <lists :parent_style=el.style></lists>
  </div>
</template>

<script>
import Lists from '@component/design_db/entity_list/Lists.vue';
export default {
  components: {
    Lists,
  },
  data() {
    return {
      el: { 
        style: {
          height: 0,
        } 
      }
    }
  },
  mounted() {
    this.el.style.height = this.$el.clientHeight-70;
  }
}
</script>

<style scoped>
  .lists {
    width: 100%;
    height: 100%;
    padding: 60px 10px 10px 10px;
    box-sizing: border-box;
    background-color: #e2e2e2;
    font-family: sans-serif;
    color: rgba(0,0,0,.87);
  }
  
</style>