<template>
  <div>
    <div class="list-group-header" @click="handleClick(!isOpened)">
      <div class="table-name">{{getTableName(table_id)}}</div>
      <div class="drop-down-button">
        <v-icon class="icon" name="angle-down" scale="1.0" v-show="!isOpened" />
        <v-icon class="icon" name="angle-up" scale="1.0" v-show="isOpened" />
      </div>
    </div>
    <transition-group @before-enter="beforeEnter" @enter="enter" @before-leave="beforeLeave" @leave="leave">
      <div class="accordion" v-if="isOpened" :key="table_id" :style="styles">
        <list-body
          class="list-group-body"
          v-for="(column, index) in columns"
          :name="column.name !== '' ? column.name : 'none'"
          :type="column.type !== ''? column.type : 'none'"
          :key="index"
          @enter="enter">
        </list-body>
      </div>
    </transition-group>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import ListBody from '@component/design_db/entity_list/ListBody.vue';
export default {
  name: 'list-content',
  components: {
    ListBody,
  },
  props: {
    table_id: Number,
  },
  data() {
    return {
      columns: [],
      isOpened: false,
      height: 0,
    }
  },
  watch: {
    getColumns: {
      handler() {
        this.columns = this.getColumns;
        console.log(this.columns)
      },
      deep: true,
    },
    columnLength: {
      handler(newValue, oldValue) {
        if (newValue > oldValue) {
          this.height += 28;
        }
        if (newValue < oldValue) {
          this.height -= 28;
        }
      },
    }
  },
  created() {
    console.log(this.table_id)
    this.columns = this.getColumns;
  },
  computed: {
    ...mapGetters('table', [ 'getOneTable', 'getTableName' ]),
    styles() {
      return Object.assign({}, this.style_height);
    },
    style_height() {
      return {'height': this.height + 'px'};
    },
    getColumns() {
      var entity = this.getOneTable(this.table_id);
      return entity.columns;
    },
    columnLength() {
      return this.columns.length;
    }
  },
  methods: {
    handleClick(trigger) {
      this.isOpened = trigger;
    },
    beforeEnter: function(el) {
      this.height = 0;
      el.style.height = this.height;
    },
    enter: function(el) {
      this.height = el.scrollHeight;
      el.style.height = this.height + 'px';
    },
    beforeLeave: function(el) {
      this.height = el.scrollHeight;
      el.style.height = this.height + 'px';
    },
    leave: function(el) {
      this.height = 0;
      el.style.height = this.height;
    }
  }
}
</script>
<style scoped>
.list-group-header {
  display: flex;
  justify-content: flex-start;
  height: 32px;
  border-left: solid 5px rgba(110, 136, 255, 0.8);
  padding: 0 15px;
  background-color: #ffffff;
}
.table-name {
  height: 32px;
  line-height: 32px;
  font-size: 16px;
  overflow: hidden;
  white-space: nowrap;
}
.drop-down-button {
  margin-left: auto;
}
.drop-down-button .icon {
  width: 32px;
  height: 32px;
  border-radius: 16px;
  padding: 6px;
  line-height: 32px;
  box-sizing: border-box;
}
.drop-down-button .icon:active {
  background-color: #e2e2e2;
}
.accordion {
  overflow: hidden;
  transition: height 0.4s ease-in-out;
}
.list-group-body {
  display: flex;
  justify-content: flex-start;
  height: 28px;
  line-height: 28px;
  padding: 0 15px 0 30px;
  background-color: #ffffff;
}
.v-enter-active {
  animation-duration: 1s;
    animation-fill-mode: both;
}
.v-leave-active {
  animation-duration: 1s;
  animation-fill-mode: both;
}
</style>