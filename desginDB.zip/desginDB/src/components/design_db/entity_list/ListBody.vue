<template>
  <div>
    <div class="column-status">{{name}}&nbsp;:&nbsp;{{type}}</div>
  </div>
</template>

<script>
export default {
  name: 'list-body',
  props: {
    name: String,
    type: String,
  },
}
</script>
<style scoped>
 .column-status {
    width: 100%;
    height: 28px;
    overflow: hidden;
    white-space: nowrap;
  }
</style>