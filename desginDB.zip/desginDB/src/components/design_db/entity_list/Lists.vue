<template>
  <div class="list-contents" role="list" :style="styles">
    <draggable
    v-model="entity_id_list">
      <list-content
        class="list-groups"
        v-for="(table_id, index) in entity_id_list"
        :key="index"
        :table_id="table_id">
      </list-content>
    </draggable>
  </div>
</template>

<script>
import { mapGetters } from 'vuex';
import draggable from 'vuedraggable';
import ListContent from '@component/design_db/entity_list/List.vue';
export default {
  name: 'table-list',
  components: {
    draggable,
    ListContent,
  },
  props: {
    parent_style: Object,
  },
  data() {
    return {
      entity_id_list: [],
    }
  },
  watch: {
    getTableIdList: function() {
      var diff_1 = this.getTableIdList.filter(el => 
        this.entity_id_list.indexOf(el) == -1
      );
      this.entity_id_list = this.entity_id_list.concat(diff_1)
      console.log(diff_1)
      console.log(this.entity_id_list)
      var deff_2 = this.entity_id_list.filter(el => 
        this.getTableIdList.indexOf(el) == -1 
      );
      console.log(deff_2)
      if (deff_2.length !== 0) {
        deff_2.array.forEach(el => {
          this.entity_id_list.some(function(val, i) {
            if (val == el) this.entity_id_list.splice(i, 1);
          });
        });
      }
    }
  },
  computed: {
    ...mapGetters('table', ['getTableIdList']),
    styles() {
      return Object.assign({}, this.height);
    },
    height() {
      return { 'height': this.parent_style.height + 'px' };
    },
  },
}
</script>

<style scoped>
  .list-contents {
    display: block;
    overflow-y: scroll;
    -ms-overflow-style: none;
    scrollbar-width: none;
  }
  .list-contents::-webkit-scrollbar {
    display:none;
  }
  .list-groups {
    border-top: solid 1px #e2e2e2;
  }
</style>