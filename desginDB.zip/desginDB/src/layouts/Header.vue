<template>
  <div class="header">
    <div class="header-title">
      DesignDB
    </div>
  </div>
</template>

<style scoped>
  .header {
    display: flex;
    position: fixed;
    z-index: 100;
    background-color: rgba(110, 136, 255);
    box-sizing: border-box;
    box-shadow: 0px 3px 5px -1px rgba(0,0,0,0.2), 0px 6px 10px 0px rgba(0,0,0,0.14), 0px 1px 18px 0px rgba(0,0,0,0.12) !important;
  }
  .header-title {
    padding: 13px 20px;;
    color: white;
    font-family: sans-serif;
    font-size: 24px;
  }
</style>