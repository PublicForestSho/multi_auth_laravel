<template>
  <div>
    <Header class="header" :style="{width: '100vw', height: 50+'px'}"></Header>
    <Content class="content" :style="{width: '100vw', height: 'calc('+100+'vh - '+50+'px)'}"></Content>
  </div>
</template>

<script>
import Header from '@layout/Header.vue';
import Content from '@layout/Content.vue';

export default {
  name: 'layout',
  components: {
    Header,
    Content,
  },
}
</script>