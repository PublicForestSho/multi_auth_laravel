import Vue from 'vue';
import Router from 'vue-router';

import DesignDB from '@component/design_db/DesignDB.vue';
import Columns from '@component/design_db/details/Columns.vue';

Vue.use(Router);

export default new Router({
  mode: 'history',
  routes: [
    {
      path: '/',
      redirect: '/design-db',
    },
    {
      path: '/design-db',
      component: DesignDB,
      redirect: '/design-db/columns',
      children: [
        {
          path: 'columns',
          name: 'columns',
          component: Columns,
        }
      ]
    }
  ]
})