import Vue from 'vue';
import Vuex from 'vuex';

import status from '@store/modules/status.js';
import table from '@store/modules/table.js';
import line from '@store/modules/line.js';

Vue.use(Vuex);

export default new Vuex.Store({
  modules: {
    status,
    table,
    line,
  }
});