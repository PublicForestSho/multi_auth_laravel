export default {
  namespaced: true,
  state: {
    id: 0,
    target: null,
    lines: [],
  },
  getters: {
    getAllLines: (state) => {
      return state.lines;
    },
    getLineId: (state) => {
      return state.id;
    },
    getTarget: (state) => {
      return state.target;
    },
    getLinePosition: (state) => (line_id, node_id, socket_id) => {
      let i = state.lines.findIndex( obj => obj.id === line_id );
      if (i !== -1) {
        let j = state.lines[i].sockets.findIndex( obj => obj.node_id === node_id && obj.socket_id === socket_id);
        if (j !== -1) {
          return state.lines[i].sockets[j].position;
        }
      }
    },
    getLinePartnerPosition: (state) => (line_id, node_id, socket_id) => {
      let i = state.lines.findIndex( obj => obj.id === line_id );
      if (i !== -1) {
        let j = state.lines[i].sockets.findIndex( obj => obj.node_id === node_id && obj.socket_id === socket_id);
        if (j !== -1) {
          j = j === 0 ? 1 : 0;
          return state.lines[i].sockets[j].position;
        }
      }
    }
  },
  mutations: {
    setLineId(state) {
      state.id++;
    },
    setTarget(state, payload) {
      state.target = payload;
    },
    setStartLinePosition(state, payload) {
      state.lines.push({
        id: state.id,
        sockets: [
          {
            node_id: payload.node_id,
            socket_id: payload.socket_id,
            position: { x: payload.position.x, y: payload.position.y },
            direction: 'right',
          },
          {
            node_id: 'mouse',
            socket_id: 'mouse',
            position: { x: payload.position.x, y: payload.position.y },
            direction: 'right',
          }
        ]
      });
    },
    setSocketPosition(state, payload) {
      let i = state.lines.findIndex( obj => obj.id === payload.line_id );
      if (i !== -1) {
        let j = state.lines[i].sockets.findIndex( obj => obj.node_id === payload.node_id && obj.socket_id === payload.socket_id );
        if (j !== -1) {
          state.lines[i].sockets[j].position.x = payload.position.x;
          state.lines[i].sockets[j].position.y = payload.position.y;
          state.lines[i].sockets[j].direction = payload.direction;
        }
      }
    },
    setSocketId(state, payload) {
      let i = state.lines.findIndex( obj => obj.id === payload.line_id );
      if (i !== -1) {
        let j = state.lines[i].sockets.findIndex( obj => obj.node_id === payload.before_node_id && obj.socket_id === payload.before_socket_id );
        if (j !== -1) {
          state.lines[i].sockets[j].node_id = payload.after_node_id;
          state.lines[i].sockets[j].socket_id = payload.after_socket_id;
        }
      }
    }
  },
  actions: {
    async drawLine( {commit}, data ) {
      await commit('setLineId');
      await commit('setTarget', data.node_id);
      await commit('setStartLinePosition', data);
    },
    async changeTarget( {commit}, data ) {
      await commit('setTarget', data);
    },
    async changeSocketPosition( {commit}, data ) {
      await commit('setSocketPosition', data);
    },
    async changeSocketId( {commit}, data ) {
      await commit('setSocketId', data);
    }
  }
}