export default {
  namespaced: true,
  state: {
    mouse: {
      position: { x: 0, y: 0},
    },
    draw: false,
    select_node: null,
    show_menu: false,
  },
  getters: {
    getMousePosition: (state) => {
      return state.mouse.position;
    },
    getDrawTrigger: (state) => {
      return state.draw;
    },
    getSelectNode: (state) => {
      return state.select_node;
    },
    getShowMenu: (state) => {
      return state.show_menu;
    },
  },
  mutations: {
    setMousePosition(state, payload) {
      state.mouse.position.x = payload.position.x;
      state.mouse.position.y = payload.position.y;
    },
    setDrawTrigger(state, payload) {
      state.draw = payload;
    },
    setSelectNode(state, payload) {
      state.select_node = payload.node_id;
    },
    setShowMenu(state, payload) {
      state.show_menu = payload;
    },
  },
  actions: {
    changeMousePosition( {commit}, position ) {
      commit('setMousePosition', {position});
    },
    switchDrawTrigger( {commit}, trigger ) {
      commit('setDrawTrigger', trigger);
    },
    changeSelectNode( {commit}, node_id ) {
      commit('setSelectNode', {node_id});
    },
    changeShowMenu( {commit}, trigger ) {
      commit('setShowMenu', trigger);
    },
  }
}