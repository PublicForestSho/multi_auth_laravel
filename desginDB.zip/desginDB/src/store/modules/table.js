function array_column($array, $name=null, $key=null){
	if(arguments.length < 1 ) throw new Error('指定する引数の数が間違っています。');
	if(!Array.isArray($array)) throw new Error('引数には、配列を指定してください。');
	var $return_data = [];
	$array.forEach($value => {
		if($key == null){
			if($name == null){
				$return_data.push($value); 
			}else{
				$return_data.push($value[$name]); 
			}
		}else{
			if($name == null){
				$return_data[$value[$key]] = $value; 
			}else{
				$return_data[$value[$key]] = $value[$name];
			}
		}
	});
	return $return_data;
}

export default {
  namespaced: true,
  state: {
    increment_id: 0,
    tables: [],

  },
  getters: {
    getTableId: (state) => {
      return state.increment_id;
    },
    getOneTable: (state) => (id) => {
      return state.tables.find( obj => obj.id === id );
    },
    getAllTables: (state) => {
      return state.tables;
    },
    getTableIdList: (state) => {
      return array_column(state.tables, 'id');
    },
    getTableName: (state, getters) => (table_id) => {
      var obj = getters.getOneTable(table_id);
      return obj.table_name;
    },
    getColumnParameter: (state, getters) => (table_id, column_id, key) => {
      var obj = getters.getOneTable(table_id);
      return obj.columns.find( obj => obj.id === column_id)[key];
    }
  },
  mutations: {
    incrementTableId(state) {
      state.increment_id++;
    },
    setTable(state, payload) {
      state.tables.push({
        id: payload.id,
        table_name: payload.data.name,
        columns: [],
        position: {x: 0, y: 0},
        increment_id: 0,
      });
    },
    setTableName(state, payload) {
      state.tables[payload.table_id-1].table_name = payload.table_name;
    },
    setColumn(state, payload) {
      state.tables[payload.id-1].increment_id++;
      state.tables[payload.id-1].columns.push({
        id: state.tables[payload.id-1].increment_id,
        name: '',
        type: '',
        pk: false,
        nn: false,
        uq: false,
        ai: false,
        un: false,
        zf: false,
        bin: false,
        def_exp: '',
      });
    },
    setColumnParameter(state, payload) {
      state.tables[payload.table_id-1].columns[payload.column_id-1][payload.key] = payload.parameter;
    },
    setModifiedTables(state, payload) {
      state.tables = payload.tables;
    },
    setModifiedColumns(state, payload) {
      state.tables[payload.table_id-1].columns = payload.columns;
    },
    setTablePosition(state, payload) {
      let index = state.tables.findIndex( obj => obj.id === payload.id );
      if (index !== undefined) {
        state.tables[index].position.x = payload.position.x;
        state.tables[index].position.y = payload.position.y;
      }
    },
  },
  actions: {
    async createTable({commit, state}, data) {
      await commit('incrementTableId');
      let id = state.increment_id;
      await commit('setTable', {id, data});
    },
    async addColumn({commit}, data) {
      await commit('setColumn', data);
    },
    async changeTableName({commit}, data) {
      await commit('setTableName', data);
    },
    async changeTablePosition( {commit }, data) {
      await commit('setTablePosition', data);
    },
    async changeColumnParameter( {commit}, data) {
      await commit('setColumnParameter', data);
    },
    async changeModifiedTables( {commit}, data) {
      await commit('setModifiedTables', data);
    },
    async changeModifiedColumns( {commit}, data) {
      await commit('setModifiedColumns', data);
    }
  }
}