<?php

namespace App\Exceptions;

use Exception;
use Illuminate\Contracts\Support\Responsable;
use Illuminate\Contracts\View\View;
use Symfony\Component\HttpFoundation\Response;
use Throwable;
use Illuminate\Support\ViewErrorBag;

class DuplicateEmailException extends Exception implements Responsable
{

    public function __construcct(
        string $message,
        int $code = 0,
        Throwable $previous = null
    ) {
        $this->factory = $factory;
        parent::__construct($message, $code, $previous);
    }

    public function toResponse($request): Response
    {
        return redirect($request->headers->get('referer'))->withErrors(['duplicateMessage' => $this->getMessage()]);
        /*return new Response(
           view($request->headers->get('referer'))->withErrors(['duplicateEmail' => 'メールアドレスが重複しています。'])
        );*/
    }
}
