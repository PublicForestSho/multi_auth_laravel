<?php

namespace App\Http\Controllers\Admin\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\AuthenticatesUsers;

class LoginController extends Controller
{
  use AuthenticatesUsers;

  protected $redirectTo = '/admin/home';

  public function __construct()
  {
    $this->middleware('guest')->except('logout');
  }

  public function showLoginForm()
  {
    return view('admin.auth.login');
  }

  public function logout(Request $request)
  {
    $this->guard('admin')->logout();

    $request->session()->invalidate();

    return $this->loggedOut($request) ?: redirect('/admin/login');
  }

  public function guard()
  {
    return \Auth::guard('admin');
  }
}
?>