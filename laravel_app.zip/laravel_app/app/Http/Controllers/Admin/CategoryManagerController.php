<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Services\ItemCategoryService;
use Illuminate\Http\Request;

class CategoryManagerController extends Controller
{
    protected $itemCategoryService;

    public function __construct(ItemCategoryService $itemCategoryService)
    {
        $this->itemCategoryService = $itemCategoryService;
    }

    public function index()
    {
        $data = $this->itemCategoryService->getAllAsList(false);
        $tree = $this->itemCategoryService->getAllAsTree(true);
        /*echo "<pre>";
        echo json_encode(['data' => $data], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT );
        echo "</pre>";*/
        return view('admin.category.categoryManager')->with(['categories' => $data, 'tree' => json_encode($tree)]);
    }

    /**
     * Show the form for creating a new category of item.
     * 
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data = $this->itemCategoryService->getAllAsList(true);
        return view('admin.category.createItemCategoryForm')->with(['categories' => $data]);
    }

    public function store(Request $request)
    {
        $this->itemCategoryService->register([
            'name' => $request->name,
            'parent' => $request->parent
        ]);
        return $this->index();
    }

    public function edit(Request $request, Int $id)
    {
        $category = $this->itemCategoryService->findTarget($request->session(), $id);
        $category_lists= $this->itemCategoryService->getAllAsList(true);
        return view('admin.category.editItemCategoryForm')->with(['category' => $category, 'category_lists' => $category_lists]);
    }

    public function update(Request $request)
    {
        $this->itemCategoryService->update(
            $request->session(),
            $request->only(['name', 'parent'])
        );
        return $this->index();
    }

    public function destroy(Request $request)
    {
        $this->itemCategoryService->delete(
            $request->session()
        );
        return $this->index();
    }

}
