<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

class RepositoryServiceProvider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->app->bind(
            \App\Repositories\Admin\Contruct\UserRepositoryInterface::class,
            \App\Repositories\Admin\UserRepository::class
        );

        $this->app->bind(
            \App\Repositories\Admin\Contruct\ItemCategoryRepositoryInterface::class,
            \App\Repositories\Admin\ItemCategoryRepository::class
        );
    }

    /**
     * Bootstrap services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
