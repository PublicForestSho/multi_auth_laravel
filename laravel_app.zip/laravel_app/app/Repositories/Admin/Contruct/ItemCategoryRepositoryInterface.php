<?php
declare(strict_type=1);

namespace App\Repositories\Admin\Contruct;

interface ItemCategoryRepositoryInterface
{
  public function create(array $data);

  public function readOne(int $id);

  public function readAll();

  public function update(int $id, array $data);

  public function delete(int $id);
}