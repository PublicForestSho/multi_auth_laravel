<?php
declare(strict_types=1);

namespace App\Repositories\Admin\Contruct;

interface UserRepositoryInterface
{
  public function create(
    string $name,
    string $email,
    string $password
  );

  public function readAll();

  public function readOne(
    int $id
  );

  public function update(
    int $id,
    array $data
  );

  public function delete(
    int $id
  );
}