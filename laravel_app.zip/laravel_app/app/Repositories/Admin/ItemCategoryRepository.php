<?php
declare(strict_types=1);

namespace App\Repositories\Admin;

use App\Exceptions\DuplicateEmailException;
use App\Models\ItemCategory;

class ItemCategoryRepository implements Contruct\ItemCategoryRepositoryInterface
{
  protected $itemCategory;

  public function __construct(ItemCategory $itemCategory)
  {
    $this->itemCategory = $itemCategory;
  }

  public function create(array $data)
  {
    \DB::beginTransaction();
    try {
      $result = $this->itemCategory->create($data);
      \DB::commit();
      return $result;
    } catch (\Exception $e) {
      //redirect();
      \DB::rollback();
      if ($e->errorInfo[1] === 1062){
        throw new DuplicateEmailException('カテゴリー名が重複しています。');
      }
    }

  }

  public function readOne(int $id)
  {
    return $this->itemCategory->find($id);
  }

  public function readAll()
  {
    return $this->itemCategory->all();
  }

  public function update(int $id, array $data)
  {
    \DB::beginTransaction();
    try {
      $result = $this->itemCategory->find($id)->update($data);
      \DB::commit();
      return $result;
    } catch (\Exception $e) {
      \DB::rollback();
      //redirect();
    }
  }

  public function delete(int $id)
  {
    \DB::beginTransaction();
    try {
      $this->itemCategory->find($id)->delete();
      \DB::commit();
    } catch (\Exception $e) {
      \DB::rollback();
      //redirect();
    }
  }
}