<?php
declare(strict_types=1);

namespace App\Repositories\Admin;

use App\Exceptions\DuplicateEmailException;
use App\Models\User;
use App\Repositories\Admin\Contruct\UserRepositoryInterface;
use Illuminate\Support\Facades\Hash;

class UserRepository implements UserRepositoryInterface
{
  
  protected $user;

  public function __construct(User $user) {
    $this->user = $user;
  }

  public function create(
    string $name,
    string $email,
    string $password
  ) {
    \DB::beginTransaction();
    try {
      $this->user->create([
        'name' => $name,
        'email' => $email,
        'hash_email' => hash('sha256', $email),
        'password' => Hash::make($password)
      ]);
      \DB::commit();
    } catch (\Exception $e) {
      \DB::rollback();
      if ($e->errorInfo[1] === 1062){
        throw new DuplicateEmailException('メールアドレスが重複しています。');
      }
    }
  }

  public function readAll()
  {
    try {
      return $this->user->all();
    } catch(\Exception $e) {

    }
  }

  public function readOne(int $id) 
  {
    try {
      return $this->user->find($id);
    } catch(\Exception $e) {

    }
  }

  public function update(int $id, array $data)
  {
    \DB::beginTransaction();
    try {
      $this->user->find($id)->update($data);
      \DB::commit();
    } catch(\Exception $e) {
      \DB::rollback();
    }
  }

  public function delete(
    int $id
  ) {
    \DB::beginTransaction();
    try {
      $this->user->find($id)->delete();
      \DB::commit();
    } catch(\Exception $e) {
      \DB::rollback();
    }
  }
}