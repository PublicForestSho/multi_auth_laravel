<?php

namespace App\Services;

use App\Repositories\Admin\Contruct\ItemCategoryRepositoryInterface;
use App\Http\Resources\ItemCategoryResource;

class ItemCategoryService
{
  private $itemCategoryRepository;

  public function __construct(ItemCategoryRepositoryInterface $itemCategoryRepository)
  {
    $this->itemCategoryRepository = $itemCategoryRepository;
  }

  public function getOne($id)
  {
    return $this->itemCategoryRepository->readOne((int)$id);
  }

  public function getAllAsTree()
  {
    $data = $this->itemCategoryRepository->readAll();
    return $this->convertToTreeStructure($data);
  }

  public function getAllAsList(bool $end) {
    $data = $this->itemCategoryRepository->readAll();
    return $this->findOutName($data, $end);
  }
  
  public function findOutName($rows, bool $end)
  {
    $result = [];
    foreach ($rows as $row) {
      $path = $row->path;
      $route_array = array_filter(explode("/", $path));
      $temp = [];
      foreach ($end === true ? $route_array : array_slice($route_array, 0, -1) as $node_id) {
        array_push($temp, ['id' => $node_id, 'name' => $rows->find($node_id)->name]);
      }
      array_push($result, ['id' => $row->id, 'name' => $row->name, 'path' => $temp]);
    }
    return $result;
  }

  public function convertToTreeStructure($rows)
  {
    $result = [];
    foreach ($rows as $row) {
      $path = $row->path;
      $route_array = array_filter(explode("/", $path));
      $temp = [];

      foreach(array_reverse($route_array)  as $i => $node_id) {
        $temp = [
          'id' => $rows->find($node_id)->id,
          'name' => $rows->find($node_id)->name,
          'path' => $rows->find($node_id)->path,
          'children' => $i === 0 ? [] : [$temp]
        ];
      }
      $this->merge($result, $temp);
    }
    return $result;
  }

  public function merge(&$current, $branch, $node='root')
  {
    if ($node === 'child') {
      $key = array_search($branch['id'], array_column($current['children'], 'id'));
      if ($key === false) {
        array_push($current['children'], $branch);
      } else {
        $this->merge($current['children'][$key], $branch['children'][0], 'child');
      }
    } else if ($node === 'root') {
      $key = array_search($branch['id'], array_column($current, 'id'));
      if ($key === false) {
        array_push($current, $branch);
      } else {
        $this->merge($current[$key], $branch['children'][0], 'child');
      }
    }
  }

  public function register(array $category)
  {
    $parent_path = $this->itemCategoryRepository->readOne($category['parent'])->path;
    $new = $this->itemCategoryRepository->create(['name' => $category['name']]);
    if (!is_null($new)) {
      $this->itemCategoryRepository->update($new['id'], ['path' => $parent_path.$new['id'].'/']);
    }
  }

  public function findTarget(Object $session, Int $id)
  {
    $category = $this->getOne($id);
    $session->put('category_id', $id);
    return $category;
  }

  public function update(Object $session, Array $data)
  {
    $parent_path = $this->itemCategoryRepository->readOne($data['parent'])->path;
    $id = (int)$session->pull('category_id');
    $this->itemCategoryRepository->update(
      $id,
      [
        'name' => $data['name'],
        'path' => $parent_path.$id.'/'
      ]
    );
  }

  public function delete(Object $session)
  {
    $this->itemCategoryRepository->delete(
      (int)$session->pull('category_id')
    );
  }
}