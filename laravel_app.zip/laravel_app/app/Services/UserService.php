<?php
declare(strict_types=1);

namespace App\Services;

use Illuminate\Support\Facade\Hash;
use App\Repositories\Admin\Contruct\UserRepositoryInterface;

class UserService
{
  protected $userRepository;

  public function __construct(
    UserRepositoryInterface $userRepository
  ) {
    $this->userRepository = $userRepository;
  }

  public function register($data)
  {
    $this->userRepository->create(
      $data['name'],
      $data['email'],
      $data['password']
    );
  }

  public function getAll()
  {
    return $this->userRepository->readAll();
  }

  public function getOne($id)
  {
    return $this->userRepository->readOne((int)$id);
  }

  public function findTarget($session, $id)
  {
    $user = $this->getOne($id);
    $session->put('user_id', $id);
    return $user;
  }

  public function update($session, $data)
  {
    $this->userRepository->update(
      (int)$session->pull('user_id'),
      $data
    );
  }

  public function delete($session) {
    $this->userRepository->delete(
      (int)$session->pull('user_id')
    );
  }
}

