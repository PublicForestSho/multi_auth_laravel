<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\Admin;
use Faker\Generator as Faker;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

$factory->define(Admin::class, function (Faker $faker) {
    $faker->locale('ja_JP');
    $now = Carbon\Carbon::now();
    $email = $faker->unique()->email;
    return [
        'name' => $faker->name,
        'email' => $email,
        'hash_email' => $email,
        'email_verified_at' => $now,
        'password' => Hash::make($faker->password),
        'remember_token' => Str::random(10),
    ];
});
