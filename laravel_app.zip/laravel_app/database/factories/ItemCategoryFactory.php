<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Models\ItemCategory;
use Faker\Generator as Faker;

$factory->define(ItemCategory::class, function (Faker $faker) {
    $faker->ocale('ja_JP');
    
    return [
        
    ];
});
