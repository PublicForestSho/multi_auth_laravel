<?php

use Illuminate\Database\Seeder;

use App\Models\ItemCategory;

class ItemCategorySeeder extends Seeder
{
    protected $item_category;
    public function __construct(ItemCategory $item_category)
    {
        $this->item_category = $item_category;
    }
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $parent = [ 'name' => 'book' ];
        $parent_id = $this->item_category->create($parent)->id;
        $this->item_category->find($parent_id)->update(['path' => '/'.$parent_id.'/']);

        $child = ['name' => 'novel'];
        $parent_path = $this->item_category->find($parent_id)->path;
        $child_id = $this->item_category->create($child)->id;
        $this->item_category->find($child_id)->update(['path' => $parent_path.$child_id.'/']);

        $child = ['name' => 'comic'];
        $parent_path = $this->item_category->find($parent_id)->path;
        $child_id = $this->item_category->create($child)->id;
        $this->item_category->find($child_id)->update(['path' => $parent_path.$child_id.'/']);

        $parent = [ 'name' => 'musical instrument' ];
        $parent_id = $this->item_category->create($parent)->id;
        $this->item_category->find($parent_id)->update(['path' => '/'.$parent_id.'/']);

        $child = ['name' => 'piano'];
        $parent_path = $this->item_category->find($parent_id)->path;
        $child_id = $this->item_category->create($child)->id;
        $parent_id = $child_id;
        $this->item_category->find($child_id)->update(['path' => $parent_path.$child_id.'/']);

        $child = ['name' => 'grand piano'];
        $parent_path = $this->item_category->find($parent_id)->path;
        $child_id = $this->item_category->create($child)->id;
        $this->item_category->find($child_id)->update(['path' => $parent_path.$child_id.'/']);
    }
}
