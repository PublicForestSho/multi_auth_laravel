<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Login</title>
</head>
<body>
  <div>
    <h1>Login</h1>
    @if (Auth::check())
    <p>{{ Auth::user()->name }}</p>
    @else
    <p>ゲスト</p>
    @endif
    <div>
      <form action="{{ route('admin.auth.login') }}" method="post">
        @csrf
        <p>
          email:
          <input type="email" name="email">
        </p>
        <p>{{ $errors->first('email') }}</p>
        <p>
          password:
          <input type="password" name="password">
        </p>
        <p>{{ $errors->first('password') }}</p>
        <input type="submit" value="send">
      </form>
    </div>
  </div>
</body>
</html>