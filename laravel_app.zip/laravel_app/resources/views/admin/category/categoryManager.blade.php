@extends('admin.layout.layout')

@section('title', 'Admin-CategoryManager')

@section('head1', 'Admin: Category')

@section('content')
<div>
    <ul>
      <li><a href="{{ route('admin.categoryManager.create') }}">カテゴリー登録</a></li>
    </ul>
</div>
<div>
  <table style="border: solid 1px #000">
    <thead> 
        <tr>
           <th style="border: solid 1px #000">name</th>
           <th style="border: solid 1px #000">route</th>
           <th style="border: solid 1px #000">edit</th>
        </tr>
    </thead>
    <tbody>
        @foreach ($categories as $category)
        <tr style="border: solid 1px #000">
          <td style="border: solid 1px #000">{{ $category['name']}}</td>
          <td style="border: solid 1px #000">
          @if (empty($category['path']))
          /
          @else
          @foreach ($category['path'] as $node)
          /<a href="#">{{ $node['name']}}&nbsp;</a>
          @endforeach
          @endif
          </td>
          <td style="border: solid 1px #000">
            <a href="{{ route('admin.categoryManager.edit', ['id' => $category['id']]) }}">編集</a>
          </td>
        </tr>
        @endforeach
    </tbody>
  </table>
</div>
@endsection()