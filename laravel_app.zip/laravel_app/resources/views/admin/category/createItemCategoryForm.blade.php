@extends('admin.layout.layout')

@section('title', 'Admin-CategoryManager')

@section('head1', 'Admin: Cerate Category')

@section('content')
<div>
  <form action="{{ route('admin.categoryManager.store') }}" method="post">
  @csrf
    <dl>
      <dt>name</dt>
      <dd>
        <input type="text" name="name">
      </dd>
      <dt>parent</dt>
      <dd>
        <select name="parent" id="">
        <option value="root">/</option>
        @foreach ($categories as $category)
          <option value="{{ $category['id'] }}">
          @foreach ($category['path'] as $node)
            /{{ $node['name'] }}
          @endforeach
          </option>
        @endforeach
        </select>
      </dd>
    </dl>
    <input type="submit" value="register">
  </form>
  <p>{{ $errors->first('duplicateMessage')}}</p>
</div>
@endsection()