@extends('admin.layout.layout')

@section('title', 'Admin-CategoryManager')

@section('head1', 'Admin: Edit Category')

@section('content')
<div>
  <form action="{{ route('admin.categoryManager.update') }}" method="post">
  @csrf
    <dl>
      <dt>name</dt>
      <dd>
        <input type="text" name="name" value="{{ $category['name'] }}">
      </dd>
      <dt>parent</dt>
      <dd>
        <select name="parent" id="">
        <option value="root">/</option>
        @foreach ($category_lists as $list)
          <option value="{{ $list['id'] }}" 
          @if ($category['id'] == $list['id'])
          selected
          @endif
          >
          @foreach ($list['path'] as $node)
            /{{ $node['name'] }}
          @endforeach
          </option>
        @endforeach
        </select>
      </dd>
    </dl>
    <input type="submit" value="update">
  </form>
  <p>{{ $errors->first('duplicateMessage')}}</p>
  </form>
    <form action="{{ route('admin.categoryManager.delete') }}" method="post">
    @csrf
      <input type="submit" value="delete">
    </form>
</div>
@endsection()