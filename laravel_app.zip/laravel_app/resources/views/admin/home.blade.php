@extends('admin.layout.layout')

@section('title', 'Admin-Home')

@section('head1', 'Admin Home')

@section('content')
    @if (Auth::guard('admin')->check())
    <p>ようこそ{{ Auth::guard('admin')->user()->name }}さん </p>
    <a href="{{ route('admin.auth.logout') }}">Logout</a>
    @else
    <p>ゲスト</p>
    @endif
@endsection()