<header>
  <div>
    <ul>
      <li><a href="{{ route('admin.userManager') }}">アカウント管理</a></li>
      <li><a href="{{ route('admin.categoryManager') }}">商品カテゴリ管理</a></li>
      <li><a href="">商品管理</a></li>
    </ul>
  </div>
</header>