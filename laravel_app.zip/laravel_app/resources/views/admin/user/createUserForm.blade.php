@extends('admin.layout.layout')

@section('title', 'Admin-UserManager')

@section('head1', 'Admin: Create User')

@section('content')
<div>
    <form action="{{ route('admin.userManager.store') }}" method="post">
      @csrf
      <dl>
        <dt>name</dt>
        <dd>
          <input type="text" name="name">
        </dd>
        <dt>email</dt>
        <dd>
          <input type="email" name="email">
        </dd>
        <dt>password</dt>
        <dd>
          <input type="text" name="password" value="{{ $token }}">
        </dd>
      </dl>
      <input type="submit" value="register">
    </form>
    <p>{{ $errors->first('duplicateMessage')}}</p>
  </div>
@endsection()