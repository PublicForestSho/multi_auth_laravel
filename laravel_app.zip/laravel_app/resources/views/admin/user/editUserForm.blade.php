@extends('admin.layout.layout')

@section('title', 'Admin-UserManager')

@section('head1', 'Admin: Edit User')

@section('content')
<div>
  <form action="{{ route('admin.userManager.update') }}" method="post">
  @csrf
      <dl>
        <dt>name</dt>
        <dd>
          <input type="text" name="name" value="{{ $user['name'] }}">
        </dd>
        <dt>email</dt>
        <dd>
          <input type="email" name="email" value="{{ $user['email'] }}">
        </dd>
      </dl>
      <input type="submit" value="update">
  </form>
    <form action="{{ route('admin.userManager.delete') }}" method="post">
    @csrf
      <input type="submit" value="delete">
    </form>
</div>
@endsection()