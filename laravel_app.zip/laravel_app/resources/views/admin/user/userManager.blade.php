@extends('admin.layout.layout')

@section('title', 'Admin-UserManager')

@section('head1', 'Admin: UserManager')

@section('content')
<div>
    <ul>
      <li><a href="{{ route('admin.userManager.create') }}">アカウント登録</a></li>
    </ul>
</div>
<div>
  <table style="border: solid 1px #000">
    <thead>
      <tr>
        <th style="border: solid 1px #000">name</th>
        <th style="border: solid 1px #000">email</th>
        <th style="border: solid 1px #000">edit</th>
      </tr>
    </thead>
    <tbody>
      @foreach ($users as $user)
      <tr style="border: solid 1px #000">
        <td style="border: solid 1px #000">{{ $user['name']}}</td>
        <td style="border: solid 1px #000">{{ $user['email']}}</td>
        <td style="border: solid 1px #000"><a href="{{ route('admin.userManager.edit', ['id' => $user['id']]) }}">編集</a></td>
      </tr>
      @endforeach
    </tbody>
  </table>
</div>
@endsection()