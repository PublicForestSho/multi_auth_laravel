<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['namespace' => 'Admin'], function() {
    Route::get('/login', 'Auth\LoginController@showLoginForm')->name('admin.auth.loginForm');
    Route::post('/login', 'Auth\LoginController@login')->name('admin.auth.login');
    Route::get('/logout', 'Auth\LoginController@logout')->name('admin.auth.logout');

    Route::middleware('auth.admin')->group(function() {
        Route::get('/home', function() {
            return view('admin.home');
        });
        Route::group(['prefix' => 'userManager'], function() {
            Route::get('/', 'UserManagerController@index')->name('admin.userManager');
            Route::get('/create', 'UserManagerController@create')->name('admin.userManager.create');
            Route::post('/store', 'UserManagerController@store')->name('admin.userManager.store');
            Route::get('/edit/{id}', 'UserManagerController@edit')->name('admin.userManager.edit');
            Route::post('/update', 'UserManagerController@update')->name('admin.userManager.update');
            Route::post('/delete', 'UserManagerController@destroy')->name('admin.userManager.delete');
        });
        Route::group(['prefix'=> 'categoryManager'], function() {
            Route::get('/', 'CategoryManagerController@index')->name('admin.categoryManager');
            Route::get('/create', 'CategoryManagerController@create')->name('admin.categoryManager.create');
            Route::post('/store', 'CategoryManagerController@store')->name('admin.categoryManager.store');
            Route::get('/edit/{id}', 'CategoryManagerController@edit')->name('admin.categoryManager.edit');
            Route::post('/update', 'CategoryManagerController@update')->name('admin.categoryManager.update');
            Route::post('/delete', 'CategoryManagerController@destroy')->name('admin.categoryManager.delete');
        });
    });
});

