<header>
  <div>
    <ul>
      <li><a href="<?php echo e(route('admin.userManager')); ?>">アカウント管理</a></li>
      <li><a href="<?php echo e(route('admin.categoryManager')); ?>">商品カテゴリ管理</a></li>
      <li><a href="">商品管理</a></li>
    </ul>
  </div>
</header><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/layout/header.blade.php ENDPATH**/ ?>