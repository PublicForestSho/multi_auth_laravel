<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>User Manager</title>
</head>
<body>
  <h1>Admin: User Manager</h1>
  <div>
      <ul>
        <li><a href="<?php echo e(route('admin.userManager.create')); ?>">アカウント登録</a></li>
      </ul>
    </div>
</body>
</html><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/userManager.blade.php ENDPATH**/ ?>