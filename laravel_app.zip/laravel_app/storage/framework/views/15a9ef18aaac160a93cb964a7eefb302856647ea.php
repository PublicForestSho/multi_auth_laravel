<?php $__env->startSection('title', 'Admin-CategoryManager'); ?>

<?php $__env->startSection('head1', 'Admin: Edit Category'); ?>

<?php $__env->startSection('content'); ?>
<div>
  <form action="<?php echo e(route('admin.categoryManager.update')); ?>" method="post">
  <?php echo csrf_field(); ?>
    <dl>
      <dt>name</dt>
      <dd>
        <input type="text" name="name" value="<?php echo e($category['name']); ?>">
      </dd>
      <dt>parent</dt>
      <dd>
        <select name="parent" id="">
        <option value="root">/</option>
        <?php $__currentLoopData = $category_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($list['id']); ?>" 
          <?php if($category['id'] == $list['id']): ?>
          selected
          <?php endif; ?>
          >
          <?php $__currentLoopData = $list['path']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            /<?php echo e($node['name']); ?>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </dd>
    </dl>
    <input type="submit" value="update">
  </form>
  <p><?php echo e($errors->first('duplicateMessage')); ?></p>
  </form>
    <form action="<?php echo e(route('admin.categoryManager.delete')); ?>" method="post">
    <?php echo csrf_field(); ?>
      <input type="submit" value="delete">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/category/editItemCategoryForm.blade.php ENDPATH**/ ?>