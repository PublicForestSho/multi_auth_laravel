<?php $__env->startSection('title', 'Admin-UserManager'); ?>

<?php $__env->startSection('head1', 'Admin: Update User'); ?>

<?php $__env->startSection('content'); ?>
<div>
  <form action="<?php echo e(route('admin.userManager.update')); ?>" method="post">
  <?php echo csrf_field(); ?>
      <dl>
        <dt>name</dt>
        <dd>
          <input type="text" name="name" value="<?php echo e($user['name']); ?>">
        </dd>
        <dt>email</dt>
        <dd>
          <input type="email" name="email" value="<?php echo e($user['email']); ?>">
        </dd>
      </dl>
      <input type="submit" value="update">
  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/user/updateUserForm.blade.php ENDPATH**/ ?>