<?php $__env->startSection('title', 'Admin-UserManager'); ?>

<?php $__env->startSection('head1', 'Admin: UserManager'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <ul>
      <li><a href="<?php echo e(route('admin.userManager.create')); ?>">アカウント登録</a></li>
    </ul>
</div>
<div>
  <table style="border: solid 1px #000">
    <thead>
      <tr>
        <th style="border: solid 1px #000">name</th>
        <th style="border: solid 1px #000">email</th>
        <th style="border: solid 1px #000">edit</th>
      </tr>
    </thead>
    <tbody>
      <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr style="border: solid 1px #000">
        <td style="border: solid 1px #000"><?php echo e($user['name']); ?></td>
        <td style="border: solid 1px #000"><?php echo e($user['email']); ?></td>
        <td style="border: solid 1px #000"><a href="<?php echo e(route('admin.userManager.edit', ['id' => $user['id']])); ?>">編集</a></td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/user/userManager.blade.php ENDPATH**/ ?>