<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Login</title>
</head>
<body>
  <div>
    <h1>Login</h1>
    <?php if(Auth::check()): ?>
    <p><?php echo e(Auth::user()->name); ?></p>
    <?php else: ?>
    <p>ゲスト</p>
    <?php endif; ?>
    <div>
      <form action="<?php echo e(route('admin.auth.login')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <p>
          email:
          <input type="email" name="email">
        </p>
        <p><?php echo e($errors->first('email')); ?></p>
        <p>
          password:
          <input type="password" name="password">
        </p>
        <p><?php echo e($errors->first('password')); ?></p>
        <input type="submit" value="send">
      </form>
    </div>
  </div>
</body>
</html><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/auth/login.blade.php ENDPATH**/ ?>