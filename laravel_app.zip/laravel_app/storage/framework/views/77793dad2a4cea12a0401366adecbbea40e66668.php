<?php $__env->startSection('title', 'Admin-UserManager'); ?>

<?php $__env->startSection('head1', 'Admin: Create User'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <form action="<?php echo e(route('admin.userManager.store')); ?>" method="post">
      <?php echo csrf_field(); ?>
      <dl>
        <dt>name</dt>
        <dd>
          <input type="text" name="name">
        </dd>
        <dt>email</dt>
        <dd>
          <input type="email" name="email">
        </dd>
        <dt>password</dt>
        <dd>
          <input type="text" name="password" value="<?php echo e($token); ?>">
        </dd>
      </dl>
      <input type="submit" value="register">
    </form>
    <p><?php echo e($errors->first('duplicateMessage')); ?></p>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/user/createUserForm.blade.php ENDPATH**/ ?>