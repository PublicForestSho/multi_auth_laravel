<?php $__env->startSection('title', 'Admin-Home'); ?>

<?php $__env->startSection('head1', 'Admin Home'); ?>

<?php $__env->startSection('content'); ?>
    <?php if(Auth::guard('admin')->check()): ?>
    <p>ようこそ<?php echo e(Auth::guard('admin')->user()->name); ?>さん </p>
    <a href="<?php echo e(route('admin.auth.logout')); ?>">Logout</a>
    <?php else: ?>
    <p>ゲスト</p>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/home.blade.php ENDPATH**/ ?>