<?php $__env->startSection('title', 'Admin-CategoryManager'); ?>

<?php $__env->startSection('head1', 'Admin: Category'); ?>

<?php $__env->startSection('content'); ?>
<div>
    <ul>
      <li><a href="<?php echo e(route('admin.categoryManager.create')); ?>">カテゴリー登録</a></li>
    </ul>
</div>
<div>
  <table style="border: solid 1px #000">
    <thead> 
        <tr>
           <th style="border: solid 1px #000">name</th>
           <th style="border: solid 1px #000">route</th>
           <th style="border: solid 1px #000">edit</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr style="border: solid 1px #000">
          <td style="border: solid 1px #000"><?php echo e($category['name']); ?></td>
          <td style="border: solid 1px #000">
          <?php if(empty($category['path'])): ?>
          /
          <?php else: ?>
          <?php $__currentLoopData = $category['path']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $node): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          /<a href="#"><?php echo e($node['name']); ?>&nbsp;</a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
          </td>
          <td style="border: solid 1px #000">
            <a href="<?php echo e(route('admin.categoryManager.edit', ['id' => $category['id']])); ?>">編集</a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
  </table>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/admin/Documents/practice/20_04_04_laravel/laravel_app/resources/views/admin/category/categoryManager.blade.php ENDPATH**/ ?>